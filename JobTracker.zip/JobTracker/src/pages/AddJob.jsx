const AddJob = () => {
    return (
    <h1>Add Job Page</h1>
    );
}

export default AddJob;


