const DeleteJob = () => {
  return (
    <h1>Delete Job: Client App</h1>
  )
}

export default DeleteJob