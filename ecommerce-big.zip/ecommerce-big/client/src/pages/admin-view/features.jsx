function AdminFeatures() {
  return <div>admin features</div>;
}

export default AdminFeatures;
