const Stats = () => {
  return (
    <h1>Stats Page</h1>
  )
}

export default Stats