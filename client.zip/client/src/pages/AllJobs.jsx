const AllJobs = () => {
  return (
    <h1>All Jobs: Client App</h1>
  )
}

export default AllJobs