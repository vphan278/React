

const Dashboard = () => {
    return (
    <h1>Dashboard Page after Login</h1>
   
    );
}

export default Dashboard



