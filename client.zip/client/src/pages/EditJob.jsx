const EditJob = () => {
  return <h1>Edit Job Page</h1>;
};

export default EditJob;


