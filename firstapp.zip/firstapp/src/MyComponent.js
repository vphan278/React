import React from 'react'

export const MyComponent = () => {
    return (
    <div>MyComponent</div>
)
}
